ĐẤT TỔ CHÂN TRUYỀN — WEBSITE DEMO MỚI, DỰNG LẠI TỪ ĐẦU

Cách mở: giải nén toàn bộ ZIP, mở Dat_To_Chan_Truyen_Website_Moi/index.html bằng trình duyệt. Giữ nguyên thư mục media.

Đã chú ý: ảnh nền dùng object-fit:contain để hiện toàn bộ ảnh; chữ tên dự án/slogan ở cột riêng không chồng lên ảnh; phân hệ trò chơi chỉ hiện ảnh nhân vật và giọng đọc, không có video player; học liệu Sẻ Chia Tri Thức hiển thị trực tiếp tại phân hệ 7; phân hệ Học Tập Thông Minh có ô chọn ảnh và kết quả mẫu demo; trống đồng có câu hỏi, trả lời đúng mới mở mảnh ghép, trả lời sai hiện gợi ý.

Các tương tác gửi ảnh, gửi duyệt, mua hàng là mô phỏng chạy trên trình duyệt, không có backend. Trò chơi dùng câu hỏi/đáp án cố định. Tệp ảnh gốc được giữ nguyên trong media với tên tệp được chuẩn hóa để đường dẫn ổn định.
